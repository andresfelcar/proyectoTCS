<?php

require_once "model/Conexion.php";

class LoginConsulta
{
    private function __construct(){}

    public static function Main($option, $array = [])
    {
        $consulta = new LoginConsulta();

        $resultado = $consulta->ConsultaLogin($array);
        return $resultado;
    }

    public function ConsultaLogin($array)
    {

        $conexion = Conexion::connection();

        $sql = "SELECT * FROM usuarios WHERE correo = ? AND contrasena = ? ";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("ss", $array[0], $array[1]);
        $stmt->execute();
        $resultado = $stmt->get_result();
        return $resultado->fetch_row();

    }
}
