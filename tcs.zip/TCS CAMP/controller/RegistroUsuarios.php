<?php
require_once "model/Conexion.php";

class RegistroUsuarios{

private function __construct(){}

public static function Main($option, $array = []){

    
$registro = new RegistroUsuarios();


switch($option){

    case 0:
        $resultado=$registro->RegistrarAsociado($array);
        break;
}

return $resultado;


}


public function RegistrarAsociado($array){
    
    $conexion = Conexion::connection();
     
    $id=intval($array[2]);

    $sql = "INSERT INTO usuarios (idUsuario,nombres,apellidos,cedula,celular,ciudad,correo,contrasena) VALUES ('$id',?,?,?,?,?,?,?)";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("sssssss",$array[0],$array[1],$array[2],$array[4],$array[3],$array[5],$array[6]);
    $stmt->execute();
    /*
    $sql2 = "SELECT MAX(idUsuario) AS id FROM usuarios";
    $resultado = $conexion->query($sql2);
    $response = $resultado->fetch_row();

    $sql3 = "UPDATE usuarios SET id_boleta = ($response[0]) WHERE idUsuario =$response[0]";
    $stmt2 = $conexion->query($sql3);

    $sql4="SELECT u.idUsuario,u.nombre,u.apellidos,u.cedula,u.id_boleta,b.codigo_boleta,b.idBoleta,u.email 
    FROM usuarios u,boletas b WHERE u.id_boleta = b.idBoleta AND u.idUsuario = $response[0]";
    $numBoletaEmail= $conexion->query($sql4);
    $boletaEmail = $numBoletaEmail->fetch_row();

    $to = "$boletaEmail[7]";
    $subject = "NUMERO DE BOLETA DREB GROUP";
    $message = "Buen Dia,".$boletaEmail[1]."Este es tu numero de boleta ".$boletaEmail[5]." debes decirlo en la entrada, Feliz resto de dia.";
    mail($to, $subject, $message);
    header('Location:index.html');*/
    return $conexion->query($sql);
    
    
 }  
}

?>