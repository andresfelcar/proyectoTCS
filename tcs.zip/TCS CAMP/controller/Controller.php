<?php

require_once "LoginConsulta.php";
require_once "ConsultarUsuarios.php";
require_once "RegistroUsuarios.php";
require_once "RegistroInformacion.php";

class Controller{

public function Registro($option,$array = []){
    return RegistroUsuarios::Main($option,$array);
}
public function RegistroInformacion($option,$array = []){
    return RegistroInformacion::Main($option,$array);
}
public function ConsultarUsuarios($option){
    return ConsultarUsuarios::Main($option);
}
public function ConsultaLogin($option,$array = []){
    return LoginConsulta::Main($option,$array);
}

}

?>