
<?php 

require_once "model/Conexion.php";

class ConsultarUsuarios{

private function __construct(){}

public static function Main($option){

    
$consulta = new ConsultarUsuarios();


switch($option){

    case 0:
        $resultado=$consulta->ConsultaAsociado();
        break;
}

return $resultado;


}


public function ConsultaAsociado(){
    
    $conexion = Conexion::connection();
     
    $sql="SELECT u.idUsuario,u.nombres,u.apellidos,u.cedula,u.ciudad,u.celular,i.profesion,i.usuario_id
    FROM usuarios u,informacionacademica i WHERE u.idUsuario = i.usuario_id";
    return $conexion->query($sql);
    

}
}
?>