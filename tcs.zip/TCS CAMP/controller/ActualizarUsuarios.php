public function RegistrarPalco($array){

$conexion = Conexion::connection();

$numPalco = (int)$array[60];
echo $numPalco;

$sql = "INSERT INTO usuariospalco (nombre,apellidos,edad,cedula,celular,email,id_boleta) VALUES
('$array[0]','$array[1]','$array[2]','$array[3]','$array[4]','$array[5]',$numPalco),
('$array[6]','$array[7]','$array[8]','$array[9]','$array[10]','$array[11]',$numPalco),
('$array[12]','$array[13]','$array[14]','$array[15]','$array[16]','$array[17]',$numPalco),
('$array[18]','$array[19]','$array[20]','$array[21]','$array[22]','$array[23]',$numPalco),
('$array[24]','$array[25]','$array[26]','$array[27]','$array[28]','$array[29]',$numPalco),
('$array[30]','$array[31]','$array[32]','$array[33]','$array[34]','$array[35]',$numPalco),
('$array[36]','$array[37]','$array[37]','$array[39]','$array[40]','$array[41]',$numPalco),
('$array[42]','$array[43]','$array[44]','$array[45]','$array[46]','$array[47]',$numPalco),
('$array[48]','$array[49]','$array[50]','$array[51]','$array[52]','$array[53]',$numPalco),
('$array[54]','$array[55]','$array[56]','$array[57]','$array[58]','$array[59]',$numPalco)";

$sql2="SELECT u.idUsuario,u.nombre,u.apellidos,u.cedula,u.id_boleta,u.estado,b.codigo_boleta,b.idBoleta 
FROM usuariospalco u,boletas b WHERE u.id_boleta = b.idBoleta AND b.idBoleta = $numPalco";
$numBoletaEmail= $conexion->query($sql2);
$boletaEmail = $numBoletaEmail->fetch_row();  


$bolet = (int)$boletaEmail[6];

if($bolet == 2301){

$to = "$array[5],$array[11],$array[17],$array[23],$array[29],$array[35],$array[41],$array[47],$array[53],$array[59]";
$subject = "NUMERO DE BOLETA DREB GROUP";
$message = "Buen Dia, Este es tu numero de boleta 2301 debes decirlo en la entrada, Feliz resto de dia.";
mail($to, $subject, $message); 
}
if($bolet == 2302){

    $to = "$array[5],$array[11],$array[17],$array[23],$array[29],$array[35],$array[41],$array[47],$array[53],$array[59]";
    $subject = "NUMERO DE BOLETA DREB GROUP";
    $message = "Buen Dia, Este es tu numero de boleta 2302 debes decirlo en la entrada, Feliz resto de dia.";
    mail($to, $subject, $message); 
    }
    if($bolet == 2303){

        $to = "$array[5],$array[11],$array[17],$array[23],$array[29],$array[35],$array[41],$array[47],$array[53],$array[59]";
        $subject = "NUMERO DE BOLETA DREB GROUP";
        $message = "Buen Dia, Este es tu numero de boleta 2303 debes decirlo en la entrada, Feliz resto de dia.";
        mail($to, $subject, $message); 
        }
        if($bolet == 2304){

            $to = "$array[5],$array[11],$array[17],$array[23],$array[29],$array[35],$array[41],$array[47],$array[53],$array[59]";
            $subject = "NUMERO DE BOLETA DREB GROUP";
            $message = "Buen Dia, Este es tu numero de boleta 2304 debes decirlo en la entrada, Feliz resto de dia.";
            mail($to, $subject, $message); 
            }
            if($bolet == 2305){

                $to = "$array[5],$array[11],$array[17],$array[23],$array[29],$array[35],$array[41],$array[47],$array[53],$array[59]";
                $subject = "NUMERO DE BOLETA DREB GROUP";
                $message = "Buen Dia, Este es tu numero de boleta 2305 debes decirlo en la entrada, Feliz resto de dia.";
                mail($to, $subject, $message); 
                }
                if($bolet == 2306){

                    $to = "$array[5],$array[11],$array[17],$array[23],$array[29],$array[35],$array[41],$array[47],$array[53],$array[59]";
                    $subject = "NUMERO DE BOLETA DREB GROUP";
                    $message = "Buen Dia, Este es tu numero de boleta 2306 debes decirlo en la entrada, Feliz resto de dia.";
                    mail($to, $subject, $message); 
                    }
                    if($bolet == 2307){

                        $to = "$array[5],$array[11],$array[17],$array[23],$array[29],$array[35],$array[41],$array[47],$array[53],$array[59]";
                        $subject = "NUMERO DE BOLETA DREB GROUP";
                        $message = "Buen Dia, Este es tu numero de boleta 2307 debes decirlo en la entrada, Feliz resto de dia.";
                        mail($to, $subject, $message); 
                        }
                        if($bolet == 2308){

                            $to = "$array[5],$array[11],$array[17],$array[23],$array[29],$array[35],$array[41],$array[47],$array[53],$array[59]";
                            $subject = "NUMERO DE BOLETA DREB GROUP";
                            $message = "Buen Dia, Este es tu numero de boleta 2308 debes decirlo en la entrada, Feliz resto de dia.";
                            mail($to, $subject, $message); 
                            }
                            if($bolet == 2309){

                                $to = "$array[5],$array[11],$array[17],$array[23],$array[29],$array[35],$array[41],$array[47],$array[53],$array[59]";
                                $subject = "NUMERO DE BOLETA DREB GROUP";
                                $message = "Buen Dia, Este es tu numero de boleta 2309 debes decirlo en la entrada, Feliz resto de dia.";
                                mail($to, $subject, $message); 
                                }
                                if($bolet == 2310){

                                    $to = "$array[5],$array[11],$array[17],$array[23],$array[29],$array[35],$array[41],$array[47],$array[53],$array[59]";
                                    $subject = "NUMERO DE BOLETA DREB GROUP";
                                    $message = "Buen Dia, Este es tu numero de boleta 2310 debes decirlo en la entrada, Feliz resto de dia.";
                                    mail($to, $subject, $message); 
                                    }