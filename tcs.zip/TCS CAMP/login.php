<?php

@session_start();
require_once "controller/Controller.php";

if (!empty($_POST['correo']) && !empty($_POST['contrasena'])) {

    $controller = new Controller();
    $array = [];
    array_push($array, $_POST['correo'], $_POST['contrasena']);
    $_SESSION['usuario'] = $controller->ConsultaLogin(0, $array);
    $resultadoConsulta = $_SESSION['usuario'];

    if ($resultadoConsulta != null) {
        header("Location:vistas/portal.html");
    } else {
        $_SESSION['usuario'] = null;
        echo "Datos incorrectos";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="assets/css/form-register.css">
    <link rel="stylesheet" href="assets/css/login.css">
    <title>Formulario inscripciones</title>
</head>

<body>
    <!------ Include the above in your HEAD tag ---------->
    <div class="register altura-div">
        <div class="row">
            <div class="col-md-3 register-left">
                <img src="assets/images/logo/logoTCS.png" alt="" />
                <h3>Bienvenido</h3>
                <p>En nuestra plataforma podras aprender mucho con nosotros.</p>
            </div>
            <div class="col-md-9 register-right">
                <div class="tab-content" id="myTabContent">
                    <!-- formulario de registro metodo post -->
                    <form action="" m method="POST">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <h3 class="register-heading">Ingresa con tu correo y contrasena.</h3>
                            <div class="row register-form">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="email" name="correo" class="form-control" placeholder="Correo *"
                                            value="" required />
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="contrasena" class="form-control"
                                            placeholder="Contrasena *" value="" required />
                                    </div>
                                    <input type="submit" class="btnRegister" value="Ingresar" />
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
</body>

</html>