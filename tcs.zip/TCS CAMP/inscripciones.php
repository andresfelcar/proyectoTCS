<?php

require_once "controller/Controller.php";

if(!empty($_POST['nombres']) && !empty($_POST['apellidos']) && !empty($_POST['cedula']) && !empty($_POST['ciudad']) && 
!empty($_POST['celular']) && !empty($_POST['correo']) && !empty($_POST['contrasena1']) && !empty($_POST['contrasena2'])
){
   
       $arrayUsuario = [];
       $arrayInformacion = [];

       array_push($arrayUsuario, $_POST['nombres'],$_POST['apellidos'],$_POST['cedula'],$_POST['ciudad'],
                          $_POST['celular'],$_POST['correo'],$_POST['contrasena1'],$_POST['contrasena2']);

       array_push($arrayInformacion, $_POST['abierta1'],$_POST['abierta2'],$_POST['actividad'],$_POST['tiempo'],
                          $_POST['empresa'],$_POST['abierta3'],$_POST['profesion'],$_POST['semestre'],$_POST['cedula']);                  
                        
                          $inscripciones = new Controller();
                          $resultado = $inscripciones->Registro(0,$arrayUsuario);
                          $resultado = $inscripciones->RegistroInformacion(0,$arrayInformacion);
     

   }

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="assets/css/form-register.css">
    <title>Formulario inscripciones</title>
</head>

<body>


    <!------ Include the above in your HEAD tag ---------->

    <div class="register">
        <div class="row">
            <div class="col-md-3 register-left">
                <img src="assets/images/logo/logoTCS.png" alt="" />
                <h3>Bienvenido</h3>
                <p>Muy pronto formaras parte de nuestra familia Assurance TCS!</p>
                
            </div>
            <div class="col-md-9 register-right">
                <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Aspirante</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Asociado</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <!-- formulario de registro metodo post -->
                 <form action="" m method="POST">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <h3 class="register-heading">Participa por el ingreso a nuestro Campus.</h3>
                        <div class="row register-form">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" name="nombres" class="form-control" placeholder="Nombres *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="text" name="apellidos" class="form-control" placeholder="Apellidos *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="text" name="cedula" class="form-control" placeholder="Cedula *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="text" name="ciudad" class="form-control" placeholder="Ciudad de Residencia *"
                                        value="" />
                                </div>
                                <div class="form-group">
                                    <input type="text" name="celular" class="form-control" placeholder="Celular *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="email" name="correo" class="form-control" placeholder="Correo *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="password" name="contrasena1" class="form-control" placeholder="Contrasena *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="password" name="contrasena2" class="form-control" placeholder="Confirmar contrasena *"
                                        value="" />
                                </div>
                                <div class="form-group">
                                    <textarea name="abierta1" id="" class="form-control" cols="30" rows="2" placeholder="¿Por qué deseas trabajar con nosotros?
                                        "></textarea>
                                </div>
                             
                            </div>
                            <div class="col-md-6">
                             
                                <div class="form-group">
                                    <textarea name="abierta2" id="" class="form-control" cols="30" rows="4"
                                        placeholder="¿Cuál es el logro profesional del que te sientes más orgulloso? Esta es tú oportunidad de sorprendernos. Aprovéchala :)"></textarea>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="actividad" >
                                        <option class="hidden"  selected disabled>Experiencia laboral (Actividad)
                                        </option>
                                        <option>Vendedor</option>
                                        <option>Soporte de sistemas</option>
                                        <option>Desarrollador</option>
                                        <option>Analista de sistemas informaticos</option>
                                        <option>Auxiliar de sistemas</option>
                                        <option>Asesor comercial</option>
                                        <option>Call center</option>
                                        <option>Analista bases de datos</option>
                                        <option>Desarrollador bases de datos</option>
                                        <option>Domiciliario</option>
                                        <option>Mensajeria</option>
                                        <option>Secretari@</option>
                                        <option>Cajer@</option>
                                        <option>Impulsador/ra</option>
                                        <option>Solo practicas</option>
                                        <option>Sin experiencia</option>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="tiempo">
                                        <option class="hidden"  selected disabled>Experiencia laboral (tiempo)
                                        </option>
                                        <option>0-6 Meses</option>
                                        <option>6-12 Meses</option>
                                        <option>Mas de 1 ano</option>
                                        
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" minlength="10" maxlength="10" name="empresa"
                                        class="form-control" placeholder="Empresa *" value="" />
                                </div>
                                <div class="form-group">
                                    <textarea name="abierta3" id="" class="form-control" cols="30" rows="2" placeholder="En que lenguajes de programacion tienes conocimiento?
                                        "></textarea>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="profesion" >
                                        <option class="hidden"  selected disabled>Estudios
                                        </option>
                                        <option>DISEÑO GRÁFICOs</option>
                                        <option>ARQUITECTURA Y AFINES</option>
                                        <option>INGENIERÍA BIOMÉDICA</option>
                                        <option>INGENIERÍA COMERCIAL</option>
                                        <option>DISEÑO GRÁFICOs</option>
                                        <option>INGENIERÍA DE DISEÑO DE PRODUCTO</option>
                                        <option>INGENIERÍA DE PROCESOS</option>
                                        <option>INGENIERÍA DE PRODUCCIÓN</option>
                                        <option>INGENIERÍA DE SISTEMAS Y AFINES</option>
                                        <option>INGENIERÍA DE TELECOMUNICACIONES</option>
                                        <option>INGENIERÍA ELÉCTRICA</option>
                                        <option>INGENIERÍA ELECTRÓNICA</option>
                                        <option>INGENIERÍA INDUSTRIAL</option>
                                        <option>INGENIERÍA MECÁNICA</option>
                                        <option>INGENIERÍA MECATRÓNICA</option>
                                        <option>DISEÑO GRÁFICO</option>
                                        <option>INGENIERÍA MULTIMEDIA</option>
                                        <option>INGENIERÍA QUÍMICA</option>
                                        <option>MANTENIMIENTO DE COMPUTADORES Y REDES</option>
                                         <option>TECNOLOGIA EN SISTEMAS</option>
                                        <option>ANALISIS Y DESARROLLO DE SISTEMAS INFORMATICOS</option>
                                        <option>TECNOLOGIA EN DISENO MULTIMEDIA</option>
                                        <option>MISION TIC</option>
                                        <option>TECNICO EN SISTEMAS</option>
                                        <option>TECNICO EN DESARROLLO DE SOFTWARE</option>
                                        <option>OTRO.</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <select class="form-control" name="semestre">
                                        <option class="hidden"  selected disabled>Nivel de estudio?
                                        </option>
                                        <option>SEMESTRE 1</option>
                                        <option>SEMESTRE 2</option>
                                        <option>SEMESTRE 3</option>
                                        <option>SEMESTRE 4</option>
                                        <option>SEMESTRE 5</option>
                                        <option>SEMESTRE 6</option>
                                        <option>SEMESTRE 7</option>
                                        <option>SEMESTRE 8</option>
                                        <option>SEMESTRE 9</option>
                                        <option>SEMESTRE 10</option>
                                        <option>FINALIZADA</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <div class="maxl">
                                        <label class="radio inline">
                                            <input type="radio" name="gender" value="male" checked>
                                            <span> Masculino </span>
                                        </label>
                                        <label class="radio inline">
                                            <input type="radio" name="gender" value="female">
                                            <span> Femenino </span>
                                        </label>
                                    </div>
                                </div>
                                













                                <input type="submit" class="btnRegister" value="Register" />
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade show" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <h3 class="register-heading">Apply as a Hirer</h3>
                        <div class="row register-form">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="First Name *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Last Name *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Email *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="text" maxlength="10" minlength="10" class="form-control"
                                        placeholder="Phone *" value="" />
                                </div>


                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="password" class="form-control" placeholder="Password *" value="" />
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" placeholder="Confirm Password *"
                                        value="" />
                                </div>
                                <div class="form-group">
                                    <select class="form-control">
                                        <option class="hidden" selected disabled>Please select your Sequrity Question
                                        </option>
                                        <option>What is your Birthdate?</option>
                                        <option>What is Your old Phone Number</option>
                                        <option>What is your Pet Name?</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="`Answer *" value="" />
                                </div>
                                <input type="submit" class="btnRegister" value="Register" />
                            </div>
                        </div>
                      </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</body>

</html>