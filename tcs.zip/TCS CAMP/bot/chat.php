<?php
include "Bot.php";
$bot = new Bot;
$questions = [
    //informacion
    "quien te creo?" => "Andres Felipe Caro Arango.",
    "cuando hay un nuevo semillero?" => "los nuevos semilleros se iran anunciando en nuestro foro 'www.campustcs.com/foro.php' y en nuestro linkedin.",
    "cuantas personas han terminado?" => "Hasta el momento TCS de la mano de Assurance a formado mas de 450 talentos.",
    

    "tu nombre es?" => "Mi nombre es " . $bot->getName(),
    "tu eres?" => "Yo soy una " . $bot->getGender()
    
];

if (isset($_GET['msg'])) {
   
    $msg = strtolower($_GET['msg']);
    $bot->hears($msg, function (Bot $botty) {
        global $msg;
        global $questions;
        if ($msg == 'hi' || $msg == "hello") {
            $botty->reply('Hola');
        } elseif ($botty->ask($msg, $questions) == "") {
            $botty->reply("Lo siento, aun estoy aprendiendo, mejorare lo mas pronto.");
        } else {
            $botty->reply($botty->ask($msg,$questions));
        }
    });
}
