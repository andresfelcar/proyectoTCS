<?php

require_once "controller/Controller.php";

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>TCS ANALYSTS.</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo/TCS-Logo-Colour-RGB.png" />

    <!-- ========================= CSS here ========================= -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/LineIcons.3.0.css" />
    <link rel="stylesheet" href="assets/css/animate.css" />
    <link rel="stylesheet" href="assets/css/tiny-slider.css" />
    <link rel="stylesheet" href="assets/css/glightbox.min.css" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <link rel="stylesheet" href="assets/css/tablaAsociados.css">
   

</head>

<body>
    <table class="table">
        <thead class="cabecera-tabla">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Foto</th>
            <th scope="col">Nombres</th>
            <th scope="col">Apellidos</th>
            <th scope="col">Profesion</th>
            <th scope="col">Ciudad</th>
            <th scope="col">Celular</th>
            <th>Hoja de vida</th>
            <th></th>
            <th></th>
            <th></th>
            
          </tr>
        </thead>
        <tbody>
            <?php
            $controller = new Controller;
            $informacion = $controller->ConsultarUsuarios(0);
            while($verInformacion = $informacion->fetch_row()){
            ?>
          <tr>
            <th scope="row"><?php echo "$verInformacion[0]" ?></th>
            <td><img src="assets/images/logo/logoTCS.png" width="100px" alt=""></td>
            <td ><?php echo "$verInformacion[1]" ?></td>
            <td ><?php echo "$verInformacion[2]" ?></td>
            <td ><?php echo "$verInformacion[6]" ?></td>
            <td ><?php echo "$verInformacion[4]" ?></td>
            <td ><?php echo "$verInformacion[5]" ?></td>
            <td><button type="button" class="btn btn-primary btn-sm btn-block">Ver +</button></td>
            <td><button type="button" class="btn btn-success btn-sm">Aprobar</button></td>
            <td><button type="button" class="btn btn-danger btn-sm">Rechazar</button></td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
</body>

</html>